import tse_option as tso

tso.pricing_based_on_stock("خودرو",100)