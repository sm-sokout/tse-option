import tse_option as tso

print(tso.pricing_based_on_stock("خودرو",100))